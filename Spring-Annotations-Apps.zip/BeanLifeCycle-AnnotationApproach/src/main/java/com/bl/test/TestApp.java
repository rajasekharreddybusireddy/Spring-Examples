package com.bl.test;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bl.beans.Motor;

public class TestApp {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		Motor motor = ctx.getBean("motor", Motor.class);
		motor.doWork();

		// closing IOC container
		ctx.close();
	}
}
