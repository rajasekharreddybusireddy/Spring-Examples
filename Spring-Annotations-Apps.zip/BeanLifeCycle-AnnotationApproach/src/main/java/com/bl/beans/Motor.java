package com.bl.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component("motor")
public class Motor {

	@PostConstruct
	public void start() {
		System.out.println("Motor:starting...");
	}

	public void doWork() {
		System.out.println("Motor:Running");
	}

	@PreDestroy
	public void stop() {
		System.out.println("Motor:stopped...");
	}

}
