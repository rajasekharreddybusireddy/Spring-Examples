package com.mr.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.app.AppConfig;
import com.app.entity.UserMaster;
import com.app.service.UserMasterService;

public class TestApp {
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		UserMasterService service = ctx.getBean("userMasterService", UserMasterService.class);
		UserMaster um = new UserMaster(101, "Raju", "raju@gmail.com");
		service.saveUser(um);
	}
}
