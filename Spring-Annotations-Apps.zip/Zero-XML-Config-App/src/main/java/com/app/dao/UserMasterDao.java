package com.app.dao;

import com.app.entity.UserMaster;

public interface UserMasterDao {

	public boolean save(UserMaster entity);

}
