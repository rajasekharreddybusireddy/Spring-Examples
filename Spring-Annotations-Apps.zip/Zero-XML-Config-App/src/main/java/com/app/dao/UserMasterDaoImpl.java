package com.app.dao;

import org.springframework.stereotype.Repository;

import com.app.entity.UserMaster;

@Repository("userMasterDao")
public class UserMasterDaoImpl implements UserMasterDao {

	/**
	 * This method is used to save user record
	 */
	public boolean save(UserMaster entity) {
		System.out.println("UserMasterDaos:save method started");
		// business logic goes here
		System.out.println("UserMasterDao:save method end");
		return true;
	}
	
	/**
	 * This method is used to save user record
	 */
	public boolean update(UserMaster entity) {
		System.out.println("UserMasterDaos:update method started");
		// business logic goes here
		System.out.println("UserMasterDao:update method end");
		return true;
	}


}
