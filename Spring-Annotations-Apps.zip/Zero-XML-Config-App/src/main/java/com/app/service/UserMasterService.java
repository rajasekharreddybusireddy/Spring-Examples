package com.app.service;

import com.app.entity.UserMaster;

public interface UserMasterService {

	public boolean saveUser(UserMaster um);

}
