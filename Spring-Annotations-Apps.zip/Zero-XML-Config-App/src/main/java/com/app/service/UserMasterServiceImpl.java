package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.app.dao.UserMasterDao;
import com.app.entity.UserMaster;

@Service("userMasterService")
@Scope(value = "prototype")
public class UserMasterServiceImpl implements UserMasterService {

	@Autowired(required = true)
	private UserMasterDao userMasterDao;

	public boolean saveUser(UserMaster um) {
		System.out.println("UserMasterService::saveUser method started");
		boolean flag = userMasterDao.save(um);
		System.out.println("UserMasterService::saveUser method ended");
		return flag;
	}

}
