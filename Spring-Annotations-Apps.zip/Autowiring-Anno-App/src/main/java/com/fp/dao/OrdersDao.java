package com.fp.dao;

import org.springframework.stereotype.Repository;

@Repository("ordersDao")
public class OrdersDao {

	public OrdersDao() {
		System.out.println("OrdersDao::constructor");
	}

	public boolean save() {
		// logic
		return true;
	}

}
