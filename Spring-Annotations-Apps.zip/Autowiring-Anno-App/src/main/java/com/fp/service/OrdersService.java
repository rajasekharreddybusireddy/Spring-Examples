package com.fp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fp.dao.OrdersDao;

@Service("orderService")
public class OrdersService {

	public OrdersService() {
		System.out.println("OrdersService::Constructor");
	}

	@Autowired(required = true)
	private OrdersDao ordersDao;

	public void setDao(OrdersDao dao) {
		this.ordersDao = dao;
	}

	public boolean insertOrder() {
		return ordersDao.save();
	}

}
