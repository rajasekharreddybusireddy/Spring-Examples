package com.fp.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fp.service.OrdersService;

public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		OrdersService service = ctx.getBean("orderService", OrdersService.class);
		boolean isInserted = service.insertOrder();
		System.out.println("Inserted ? : " + isInserted);
	}
}
