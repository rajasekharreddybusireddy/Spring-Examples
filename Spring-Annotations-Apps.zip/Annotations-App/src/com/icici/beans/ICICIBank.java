package com.icici.beans;

public class ICICIBank extends Bank {

	public double getRi() {
		return super.getRi();
	}

}
