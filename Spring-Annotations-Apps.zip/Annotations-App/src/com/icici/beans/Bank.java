package com.icici.beans;

public class Bank {

	/**
	 * 
	 * @return
	 */
	public double getRi() {
		return 10.5;
	}

}
