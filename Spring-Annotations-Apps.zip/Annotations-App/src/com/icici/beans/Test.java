package com.icici.beans;

public class Test {

	public static void main(String[] args) {

		ICICIBank bank = new ICICIBank();
		double ri = bank.getRi();
		System.out.println("RI : " + ri);
	}

}
